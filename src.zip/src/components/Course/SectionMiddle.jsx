import React from 'react'

const SectionMiddle = () => {
  return (
    <div>
      
    </div>
  )
}

export default SectionMiddle
