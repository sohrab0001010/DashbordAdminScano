import { FcLike } from "react-icons/fc";
import { FcReading } from "react-icons/fc";
import { FcGraduationCap } from "react-icons/fc";
import { FcFlashOn } from "react-icons/fc";

const course = [
  {
    gradeId: 4,
    emoji: "📒",
    color: "#FFB900",
    subject: "ریاضی",
    nameGrade: "پایه چهارم",
    contentCourse: [
      {
        name: "کاربرگ ها",
        title: "workSheet",
        content: [
          {
            chapter: 1,
            levels: [
              {
                codeNumber: 411,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                      
                    },
                    {
                      isFree: true, 
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 412,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              
              {
                codeNumber: 413,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
                
              },
              {
                codeNumber: 414,
                level: "levelFour",
                title: "تیز هوشان",
                
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
                
              },
            ],
          },
          {
            
            chapter: 2,
            levels: [
              {
                codeNumber: 421,
                level: "levelOne",
                
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                
                codeNumber: 422,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,  
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 423,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 424,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false, 
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            chapter: 3,
            levels: [
              {
                
                codeNumber: 431,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              
              {
                codeNumber: 432,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
                
              },
              {
                codeNumber: 433,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
                
              },
              {
                codeNumber: 434,
                level: "levelFour",
                title: "تیز هوشان",
                
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                },
              },
            ],
          },
          
          {
            chapter: 4,
            levels: [
              {
                codeNumber: 441,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 442,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 443,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 444,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
            
          },
          {
            chapter: 5,
            levels: [
              
              {
                codeNumber: 451,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
                
              },
              {
                codeNumber: 452,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
                
              },
              {
                codeNumber: 453,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                },
              },
              {
                codeNumber: 454,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            chapter: 6,
            levels: [
              {
                codeNumber: 461,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 462,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  
                },
              },
              {
                codeNumber: 463,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                
                codeNumber: 464,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
              
            ],
          },
          {
            chapter: 7,
            
            levels: [
              {
                codeNumber: 471,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
                
              },
              {
                codeNumber: 472,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 473,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 474,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            chapter: 8,
            levels: [
              {
                codeNumber: 481,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
                
              },
              {
                codeNumber: 482,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  
                },
              },
              {
                codeNumber: 483,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                
                codeNumber: 484,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
            
          },
        ],
      },
      {
        
        name: "امتحانات دی ماه",
        title: "examDey",
        content: [
          {
            chapter: 1,
            levels: [
              {
                codeNumber: 411,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 412,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
                
              },
              {
                codeNumber: 413,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
                
              },
              {
                codeNumber: 414,
                level: "levelFour",
                title: "تیز هوشان",
                
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                  
                },
              },
            ],
          },
          
          {
            chapter: 2,
            levels: [
              {
                
                codeNumber: 421,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 422,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 423,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 424,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 3,
            levels: [
              
              {
                codeNumber: 431,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
                
              },
              {
                codeNumber: 432,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
                
              },
              {
                codeNumber: 433,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                  
                },
              },
              {
                codeNumber: 434,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
            
          },
          {
            chapter: 4,
            levels: [
              {
                codeNumber: 441,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 442,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 443,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                
                codeNumber: 444,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
              
            ],
          },
          {
            chapter: 5,
            
            levels: [
              {
                codeNumber: 451,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
                
              },
              {
                codeNumber: 452,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                  
                },
              },
              {
                codeNumber: 453,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 454,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 6,
            levels: [
              {
                codeNumber: 461,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 462,
                level: "levelTow",
                
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                
                codeNumber: 463,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              
              {
                codeNumber: 464,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                  
                },
              },
            ],
          },
          
          {
            chapter: 7,
            levels: [
              {
                
                codeNumber: 471,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 472,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
                
              },
              {
                codeNumber: 473,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 474,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 8,
            levels: [
              {
                codeNumber: 481,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
                
              },
              {
                codeNumber: 482,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                  
                },
              },
              {
                codeNumber: 483,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                  
                },
              },
              {
                codeNumber: 484,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
            
          },
        ],
      },
      {
        
        name: "امتحانات خرداد ماه",
        title: "examKhordad",
        content: [
          {
            chapter: 1,
            levels: [
              {
                codeNumber: 411,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 412,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 413,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
                
              },
              {
                codeNumber: 414,
                level: "levelFour",
                title: "تیز هوشان",
                
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                  
                },
              },
            ],
          },
          
          {
            chapter: 2,
            levels: [
              {
                
                codeNumber: 421,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 422,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              
              {
                codeNumber: 423,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 424,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 3,
            levels: [
              
              {
                codeNumber: 431,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 432,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
                
              },
              {
                codeNumber: 433,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                  
                },
              },
              {
                codeNumber: 434,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
            
          },
          {
            chapter: 4,
            levels: [
              {
                codeNumber: 441,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 442,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 443,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                
                codeNumber: 444,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
            
          },
          {
            chapter: 5,
            levels: [
              
              {
                codeNumber: 451,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
                
              },
              {
                codeNumber: 452,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                  
                },
              },
              {
                codeNumber: 453,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 454,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
            
          },
          {
            chapter: 6,
            levels: [
              
              {
                codeNumber: 461,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
                
              },
              {
                codeNumber: 462,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                  
                },
              },
              {
                codeNumber: 463,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 464,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 7,
            levels: [
              {
                codeNumber: 471,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                  
                },
              },
              {
                codeNumber: 472,
                level: "levelTow",
                
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                
                codeNumber: 473,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                
                codeNumber: 474,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
              
            ],
          },
          {
            chapter: 8,
            
            levels: [
              {
                codeNumber: 481,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 482,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 483,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 484,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
                
              },
            ],
          },
        ],
        
      },
    ],
  },
  {
    gradeId: 5,
    emoji: "📙",
    color: "#F97316",
    subject: "ریاضی",
    
    nameGrade: "پایه پنجم",
    contentCourse: [
      {
        name: "کاربرگ ها",
        
        title: "workSheet",
        content: [
          {
            chapter: 1,
            levels: [
              {
                codeNumber: 511,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 512,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 513,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              
              {
                codeNumber: 514,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
                
              },
            ],
          },
          {
            
            chapter: 2,
            levels: [
              {
                codeNumber: 521,
                level: "levelOne",
                
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  
                },
              },
              {
                codeNumber: 522,
                level: "levelTow",
                
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                
                codeNumber: 523,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 524,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            chapter: 3,
            levels: [
              {
                codeNumber: 531,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 532,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 533,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
                
              },
              {
                codeNumber: 534,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
                
              },
            ],
          },
          {            chapter: 4,
            levels: [
              {
                codeNumber: 531,
                level: "levelOne",                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 532,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 533,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 534,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            chapter: 5,
            levels: [
              {
                codeNumber: 551,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 552,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 553,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 554,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
                
              },
            ],
          },
          {
            
            chapter: 6,
            levels: [
              {
                codeNumber: 561,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 562,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 563,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 564,
                level: "levelFour",
                title: "تیز هوشان",
                
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                },
              },
            ],
          },
          
          {
            chapter: 7,
            levels: [
              {
                
                codeNumber: 571,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              
              {
                codeNumber: 572,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              
              {
                codeNumber: 573,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
                
              },
              {
                codeNumber: 574,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            chapter: 8,
            levels: [
              {
                codeNumber: 581,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 582,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
                
              },
              {
                codeNumber: 583,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                },
              },
              {
                codeNumber: 584,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
            
          },
        ],
      },
      {
        
        name: "امتحانات دی ماه",
        title: "examDey",
        content: [
          {
            chapter: 1,
            levels: [
              {
                codeNumber: 511,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 512,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 513,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
                
              },
              {
                codeNumber: 514,
                level: "levelFour",
                title: "تیز هوشان",
                
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
                
              },
            ],
          },
          {
            
            chapter: 2,
            levels: [
              {
                codeNumber: 521,
                level: "levelOne",
                
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                
                codeNumber: 522,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              
              {
                codeNumber: 523,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 524,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 3,
            levels: [
              {
                codeNumber: 531,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 532,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
                
              },
              {
                codeNumber: 533,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              
              {
                codeNumber: 534,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
                
              },
            ],
          },
          {
            
            chapter: 4,
            levels: [
              {
                codeNumber: 541,
                level: "levelOne",
                
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                
                codeNumber: 542,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 543,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 544,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 5,
            levels: [
              {
                
                codeNumber: 551,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 552,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              
              {
                codeNumber: 553,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
                
              },
              {
                codeNumber: 554,
                level: "levelFour",
                title: "تیز هوشان",
                
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                  
                },
              },
            ],
          },
          
          {
            chapter: 6,
            levels: [
              {
                codeNumber: 561,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 562,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 563,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 564,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
            
          },
          {
            chapter: 7,
            levels: [
              
              {
                codeNumber: 571,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 572,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
                
              },
              {
                codeNumber: 573,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                  
                },
              },
              {
                codeNumber: 574,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 8,
            levels: [
              {
                codeNumber: 581,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 582,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                  
                },
              },
              {
                codeNumber: 583,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                
                codeNumber: 584,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
            
          },
        ],
      },
      {
        
        name: "امتحانات خرداد ماه",
        title: "examKhordad",
        content: [
          {
            chapter: 1,
            
            levels: [
              {
                codeNumber: 511,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 512,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 513,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 514,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
                
              },
            ],
          },
          {
            
            chapter: 2,
            levels: [
              {
                codeNumber: 521,
                level: "levelOne",
                
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                
                codeNumber: 522,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              
              {
                codeNumber: 523,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              
              {
                codeNumber: 524,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
                
              },
            ],
          },
          {
            
            chapter: 3,
            levels: [
              {
                codeNumber: 531,
                level: "levelOne",
                
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                
                codeNumber: 532,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 533,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 534,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 4,
            levels: [
              {
                
                codeNumber: 541,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 542,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              
              {
                codeNumber: 543,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
                
              },
              {
                codeNumber: 544,
                level: "levelFour",
                title: "تیز هوشان",
                
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                  
                },
              },
            ],
          },
          
          {
            chapter: 5,
            levels: [
              {
                codeNumber: 551,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 552,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 553,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 554,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
            
          },
          {
            chapter: 6,
            levels: [
              
              {
                codeNumber: 561,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 562,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
                
              },
              {
                codeNumber: 563,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                  
                },
              },
              {
                codeNumber: 564,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 7,
            levels: [
              {
                codeNumber: 571,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 572,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                  
                },
              },
              {
                codeNumber: 573,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                
                codeNumber: 574,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
            
          },
          {
            chapter: 8,
            levels: [
              
              {
                codeNumber: 581,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
                
              },
              {
                codeNumber: 582,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 583,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 584,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
        ],
      },
      
    ],
  },
  {
    gradeId: 6,
    
    emoji: "📘",
    color: "#2563EB",
    subject: "ریاضی",
    nameGrade: "پایه ششم",
    
    contentCourse: [
      {
        name: "کاربرگ ها",
        title: "workSheet",
        
        content: [
          {
            chapter: 1,
            levels: [
              
              {
                codeNumber: 611,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 612,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 613,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 614,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            chapter: 2,
            levels: [
              
              {
                codeNumber: 621,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
                
              },
              {
                codeNumber: 622,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
                
              },
              {
                codeNumber: 623,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                },
              },
              {
                codeNumber: 624,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
            
          },
          {
            chapter: 3,
            levels: [
              {
                codeNumber: 631,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 632,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 633,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                
                codeNumber: 634,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
              
            ],
          },
          {
            chapter: 4,
            
            levels: [
              {
                codeNumber: 641,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
                
              },
              {
                codeNumber: 642,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  
                },
              },
              {
                codeNumber: 643,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 644,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            chapter: 5,
            levels: [
              {
                codeNumber: 651,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 652,
                level: "levelTow",
                
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                
                codeNumber: 653,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              
              {
                codeNumber: 654,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
              
            ],
          },
          {
            chapter: 6,
            
            levels: [
              {
                codeNumber: 661,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  
                },
              },
              {
                codeNumber: 662,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 663,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 664,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            
            chapter: 7,
            levels: [
              {
                codeNumber: 671,
                level: "levelOne",
                
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                
                codeNumber: 672,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              
              {
                codeNumber: 673,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              
              {
                codeNumber: 674,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
                
              },
            ],
          },
          {
            chapter: 8,
            levels: [
              {
                codeNumber: 681,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 682,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 683,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 684,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
                
              },
            ],
          },
        ],
        
      },
      {
        name: "امتحانات دی ماه",
        title: "examDey",
        
        content: [
          {
            chapter: 1,
            levels: [
              
              {
                codeNumber: 611,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
                
              },
              {
                codeNumber: 612,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
                
              },
              {
                codeNumber: 613,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 614,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 2,
            
            levels: [
              {
                codeNumber: 621,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
                
              },
              {
                codeNumber: 622,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                  
                },
              },
              {
                codeNumber: 623,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                
                codeNumber: 624,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
              
            ],
          },
          {
            chapter: 3,
            levels: [
              {
                codeNumber: 631,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 632,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 633,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              
              {
                codeNumber: 634,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
              
            ],
          },
          {
            chapter: 4,
            
            levels: [
              {
                codeNumber: 641,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                  
                },
              },
              {
                codeNumber: 642,
                level: "levelTow",
                
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                
                codeNumber: 643,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 644,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 5,
            levels: [
              {
                codeNumber: 651,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                
                codeNumber: 652,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              
              {
                codeNumber: 653,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              
              {
                codeNumber: 654,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
                
              },
            ],
          },
          {
            
            chapter: 6,
            levels: [
              {
                codeNumber: 661,
                level: "levelOne",
                
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 662,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 663,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 664,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          
          {
            chapter: 7,
            levels: [
              {
                
                codeNumber: 671,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 672,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 673,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 674,
                level: "levelFour",
                title: "تیز هوشان",
                
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                  
                },
              },
            ],
          },
          
          {
            chapter: 8,
            levels: [
              {
                
                codeNumber: 681,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 682,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              
              {
                codeNumber: 683,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
                
              },
              {
                codeNumber: 684,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
        ],
      },
      {
        name: "امتحانات خرداد ماه",
        title: "examKhordad",
        content: [
          {
            chapter: 1,
            
            levels: [
              {
                codeNumber: 611,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
                
              },
              {
                codeNumber: 612,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                  
                },
              },
              {
                codeNumber: 613,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                
                codeNumber: 614,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
              
            ],
          },
          {
            chapter: 2,
            levels: [
              {
                codeNumber: 621,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 622,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 623,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              
              {
                codeNumber: 624,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
              
            ],
          },
          {
            chapter: 3,
            
            levels: [
              {
                codeNumber: 631,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                  
                },
              },
              {
                codeNumber: 632,
                level: "levelTow",
                
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                
                codeNumber: 633,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 634,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 4,
            levels: [
              {
                codeNumber: 641,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                
                codeNumber: 642,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              
              {
                codeNumber: 643,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              
              {
                codeNumber: 644,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
                
              },
            ],
          },
          {
            
            chapter: 5,
            levels: [
              {
                codeNumber: 651,
                level: "levelOne",
                
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 652,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 653,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 654,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          
          {
            chapter: 6,
            levels: [
              {
                
                codeNumber: 661,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 662,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                
                codeNumber: 663,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              
              {
                codeNumber: 664,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
                
              },
            ],
          },
          {
            
            chapter: 7,
            levels: [
              {
                codeNumber: 671,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 672,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 673,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 674,
                level: "levelFour",
                title: "تیز هوشان",
                
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                  
                },
              },
            ],
          },
          
          {
            chapter: 8,
            levels: [
              {
                
                codeNumber: 681,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                
                codeNumber: 682,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              
              {
                codeNumber: 683,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
                
              },
              {
                codeNumber: 684,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
        ],
      },
    ],
  },
  {
    gradeId: 7,
    emoji: "📗",
    color: "#16A34A",
    subject: "ریاضی",
    nameGrade: "پایه هفتم",
    contentCourse: [
      {
        
        name: "کاربرگ ها",
        title: "workSheet",
        content: [
          {
            
            chapter: 1,
            levels: [
              {
                codeNumber: 711,
                level: "levelOne",
                
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                
                codeNumber: 712,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              
              {
                codeNumber: 713,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 714,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            chapter: 2,
            levels: [
              {
                codeNumber: 721,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              
              {
                codeNumber: 722,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
                
              },
              {
                codeNumber: 723,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
                
              },
              {
                codeNumber: 724,
                level: "levelFour",
                title: "تیز هوشان",
                
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                },
              },
            ],
          },
          
          {
            chapter: 3,
            levels: [
              {
                
                codeNumber: 731,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 732,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 733,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 734,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
            
          },
          {
            chapter: 4,
            levels: [
              
              {
                codeNumber: 741,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
                
              },
              {
                codeNumber: 742,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
                
              },
              {
                codeNumber: 743,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                },
              },
              {
                codeNumber: 744,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            chapter: 5,
            levels: [
              {
                codeNumber: 751,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 752,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 753,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 754,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
            
          },
          {
            chapter: 6,
            levels: [
              
              {
                codeNumber: 761,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              
              {
                codeNumber: 762,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
                
              },
              {
                codeNumber: 763,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                },
              },
              {
                codeNumber: 764,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            chapter: 7,
            levels: [
              {
                codeNumber: 771,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 772,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  
                },
              },
              {
                codeNumber: 773,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                
                codeNumber: 774,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
            
          },
          {
            chapter: 8,
            levels: [
              
              {
                codeNumber: 781,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
                
              },
              {
                codeNumber: 782,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 783,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 784,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
        ],
      },
      
      {
        name: "امتحانات دی ماه",
        title: "examDey",
        content: [
          
          {
            chapter: 1,
            levels: [
              {
                
                codeNumber: 711,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 712,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
                
              },
              {
                codeNumber: 713,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
                
              },
              {
                codeNumber: 714,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 2,
            levels: [
              {
                codeNumber: 721,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
                
              },
              {
                codeNumber: 722,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
                
              },
              {
                codeNumber: 723,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                  
                },
              },
              {
                codeNumber: 724,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
            
          },
          {
            chapter: 3,
            levels: [
              
              {
                codeNumber: 731,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 732,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 733,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 734,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
              
            ],
          },
          {
            chapter: 4,
            
            levels: [
              {
                codeNumber: 741,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 742,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 743,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                
                codeNumber: 744,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
              
            ],
          },
          {
            chapter: 5,
            
            levels: [
              {
                codeNumber: 751,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
                
              },
              {
                codeNumber: 752,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                  
                },
              },
              {
                codeNumber: 753,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 754,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 6,
            levels: [
              {
                codeNumber: 761,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 762,
                level: "levelTow",
                
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                
                codeNumber: 763,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              
              {
                codeNumber: 764,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
              
            ],
          },
          {
            chapter: 7,
            
            levels: [
              {
                codeNumber: 771,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                  
                },
              },
              {
                codeNumber: 772,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 773,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 774,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            
            chapter: 8,
            levels: [
              {
                codeNumber: 781,
                level: "levelOne",
                
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                
                codeNumber: 782,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              
              {
                codeNumber: 783,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              
              {
                codeNumber: 784,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
                
              },
            ],
          },
        ],
      },
      {
        name: "امتحانات خرداد ماه",
        title: "examKhordad",
        content: [
          {
            chapter: 1,
            levels: [
              {
                codeNumber: 711,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
                
              },
              {
                codeNumber: 712,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
                
              },
              {
                codeNumber: 713,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                  
                },
              },
              {
                codeNumber: 714,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
            
          },
          {
            chapter: 2,
            levels: [
              
              {
                codeNumber: 721,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 722,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 723,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 724,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
              
            ],
          },
          {
            chapter: 3,
            
            levels: [
              {
                codeNumber: 731,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 732,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
                
              },
              {
                codeNumber: 733,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                  
                },
              },
              {
                codeNumber: 734,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
            
          },
          {
            chapter: 4,
            levels: [
              {
                codeNumber: 741,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 742,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 743,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                
                codeNumber: 744,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
            
          },
          {
            chapter: 5,
            levels: [
              
              {
                codeNumber: 751,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
                
              },
              {
                codeNumber: 752,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                  
                },
              },
              {
                codeNumber: 753,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 754,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 6,
            levels: [
              {
                codeNumber: 761,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 762,
                level: "levelTow",
                
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                
                codeNumber: 763,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                
                codeNumber: 764,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
              
            ],
          },
          {
            chapter: 7,
            
            levels: [
              {
                codeNumber: 771,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                  
                },
              },
              {
                codeNumber: 772,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 773,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 774,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            
            chapter: 8,
            levels: [
              {
                codeNumber: 781,
                level: "levelOne",
                
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                
                codeNumber: 782,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                
                codeNumber: 783,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              
              {
                codeNumber: 784,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
                
              },
            ],
          },
        ],
      },
    ],
  },
  {
    gradeId: 8,
    emoji: "📕",
    color: "#DC2626",
    subject: "ریاضی",
    nameGrade: "پایه هشتم",
    contentCourse: [
      {
        
        name: "کاربرگ ها",
        title: "workSheet",
        content: [
          {
            
            chapter: 1,
            levels: [
              {
                codeNumber: 811,
                level: "levelOne",
                
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  
                },
              },
              {
                codeNumber: 812,
                level: "levelTow",
                
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                
                codeNumber: 813,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              
              {
                codeNumber: 814,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            chapter: 2,
            levels: [
              {
                codeNumber: 821,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 822,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 823,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              
              {
                codeNumber: 824,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
              
            ],
          },
          {
            chapter: 3,
            
            levels: [
              {
                codeNumber: 831,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  
                },
              },
              {
                codeNumber: 832,
                level: "levelTow",
                
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                
                codeNumber: 833,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 834,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            chapter: 4,
            levels: [
              {
                codeNumber: 841,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                
                codeNumber: 842,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              
              {
                codeNumber: 843,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              
              {
                codeNumber: 844,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
                
              },
            ],
          },
          {
            
            chapter: 5,
            levels: [
              {
                codeNumber: 851,
                level: "levelOne",
                
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 852,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 853,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 854,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          
          {
            chapter: 6,
            levels: [
              {
                
                codeNumber: 861,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              
              {
                codeNumber: 862,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              
              {
                codeNumber: 863,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
                
              },
              {
                codeNumber: 864,
                level: "levelFour",
                title: "تیز هوشان",
                
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                },
              },
            ],
          },
          {
            chapter: 7,
            levels: [
              {
                codeNumber: 871,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 872,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 873,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                },
              },
              {
                codeNumber: 874,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
            
          },
          {
            chapter: 8,
            levels: [
              
              {
                codeNumber: 881,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              
              {
                codeNumber: 882,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
                
              },
              {
                codeNumber: 883,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 884,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
        ],
      },
      {
        name: "امتحانات دی ماه",
        title: "examDey",
        content: [
          {
            chapter: 1,
            levels: [
              {
                codeNumber: 811,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 812,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 813,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
                
              },
              {
                codeNumber: 814,
                level: "levelFour",
                title: "تیز هوشان",
                
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
                
              },
            ],
          },
          {
            
            chapter: 2,
            levels: [
              {
                codeNumber: 821,
                level: "levelOne",
                
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                
                codeNumber: 822,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              
              {
                codeNumber: 823,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 824,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 3,
            levels: [
              {
                codeNumber: 831,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 832,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
                
              },
              {
                codeNumber: 833,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
                
              },
              {
                codeNumber: 834,
                level: "levelFour",
                title: "تیز هوشان",
                
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                  
                },
              },
            ],
          },
          
          {
            chapter: 4,
            levels: [
              {
                
                codeNumber: 841,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 842,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 843,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 844,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
            
          },
          {
            chapter: 5,
            levels: [
              
              {
                codeNumber: 851,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
                
              },
              {
                codeNumber: 852,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
                
              },
              {
                codeNumber: 853,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                  
                },
              },
              {
                codeNumber: 854,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 6,
            levels: [
              {
                codeNumber: 861,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 862,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 863,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                
                codeNumber: 864,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
              
            ],
          },
          {
            chapter: 7,
            
            levels: [
              {
                codeNumber: 871,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
                
              },
              {
                codeNumber: 872,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                  
                },
              },
              {
                codeNumber: 873,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 874,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 8,
            levels: [
              {
                codeNumber: 881,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 882,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                  
                },
              },
              {
                codeNumber: 883,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                
                codeNumber: 884,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
            
          },
        ],
      },
      {
        
        name: "امتحانات خرداد ماه",
        title: "examKhordad",
        content: [
          {
            chapter: 1,
            
            levels: [
              {
                codeNumber: 811,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 812,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 813,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 814,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
                
              },
            ],
          },
          {
            
            chapter: 2,
            levels: [
              {
                codeNumber: 821,
                level: "levelOne",
                
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                
                codeNumber: 822,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              
              {
                codeNumber: 823,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              
              {
                codeNumber: 824,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 3,
            levels: [
              {
                codeNumber: 831,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 832,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              
              {
                codeNumber: 833,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
                
              },
              {
                codeNumber: 834,
                level: "levelFour",
                title: "تیز هوشان",
                
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                  
                },
              },
            ],
          },
          
          {
            chapter: 4,
            levels: [
              {
                
                codeNumber: 841,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 842,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 843,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 844,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
            
          },
          {
            chapter: 5,
            levels: [
              
              {
                codeNumber: 851,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 852,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
                
              },
              {
                codeNumber: 853,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                  
                },
              },
              {
                codeNumber: 854,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 6,
            levels: [
              {
                codeNumber: 861,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 862,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 863,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                
                codeNumber: 864,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          
          {
            chapter: 7,
            levels: [
              {
                
                codeNumber: 871,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              
              {
                codeNumber: 872,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
                
              },
              {
                codeNumber: 873,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                  
                },
              },
              {
                codeNumber: 874,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                  
                },
              },
            ],
          },
          {
            chapter: 8,
            levels: [
              {
                codeNumber: 881,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 882,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                  
                },
              },
              {
                codeNumber: 883,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                  
                },
              },
              {
                codeNumber: 884,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
            
          },
        ],
      },
    ],
    
  },
  {
    gradeId: 9,
    emoji: "📔",
    
    color: "#F7D7C4",
    subject: "ریاضی",
    nameGrade: "پایه نهم",
    contentCourse: [
      {
        name: "کاربرگ ها",
        title: "workSheet",
        content: [
          {
            chapter: 1,
            levels: [
              {
                codeNumber: 911,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
                
              },
              {
                codeNumber: 912,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
                
              },
              {
                codeNumber: 913,
                level: "levelThree",
                title: "سخت",
                
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  
                },
              },
              {
                codeNumber: 914,
                level: "levelFour",
                
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
            
          },
          {
            chapter: 2,
            levels: [
              
              {
                codeNumber: 921,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 922,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 923,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 924,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
              
            ],
          },
          {
            chapter: 3,
            
            levels: [
              {
                codeNumber: 931,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
                
              },
              {
                codeNumber: 932,
                level: "levelTow",
                title: "متوسط",
                
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  
                },
              },
              {
                codeNumber: 933,
                level: "levelThree",
                
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                
                codeNumber: 934,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            chapter: 4,
            levels: [
              {
                codeNumber: 941,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 942,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: true,
                      
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                
                codeNumber: 943,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              
              {
                codeNumber: 944,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
              
            ],
          },
          {
            chapter: 5,
            
            levels: [
              {
                codeNumber: 951,
                level: "levelOne",
                title: "آسان",
                
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  
                },
              },
              {
                codeNumber: 952,
                level: "levelTow",
                
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 953,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                      
                    },
                    {
                      isFree: false,
                      
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 954,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            chapter: 6,
            levels: [
              {
                codeNumber: 961,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 962,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 963,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 964,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            chapter: 7,
            levels: [
              {
                codeNumber: 971,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 972,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 973,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 974,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
          {
            chapter: 8,
            levels: [
              {
                codeNumber: 981,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  pdf: "/pdfs/1.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                },
              },
              {
                codeNumber: 982,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  pdf: "/pdfs/2.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                },
              },
              {
                codeNumber: 983,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  pdf: "/pdfs/3.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                },
              },
              {
                codeNumber: 984,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  pdf: "/pdfs/4.pdf",
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                },
              },
            ],
          },
        ],
      },
      {
        name: "امتحانات دی ماه",
        title: "examDey",
        content: [
          {
            chapter: 1,
            levels: [
              {
                codeNumber: 911,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 912,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 913,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 914,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 2,
            levels: [
              {
                codeNumber: 921,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 922,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 923,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 924,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 3,
            levels: [
              {
                codeNumber: 931,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 932,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 933,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 934,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 4,
            levels: [
              {
                codeNumber: 941,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 942,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 943,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 944,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 5,
            levels: [
              {
                codeNumber: 951,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 952,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 953,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 954,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 6,
            levels: [
              {
                codeNumber: 961,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 962,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 963,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 964,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 7,
            levels: [
              {
                codeNumber: 971,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 972,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 973,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 974,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 8,
            levels: [
              {
                codeNumber: 981,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 982,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 983,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 984,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
        ],
      },
      {
        name: "امتحانات خرداد ماه",
        title: "examKhordad",
        content: [
          {
            chapter: 1,
            levels: [
              {
                codeNumber: 911,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 912,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 913,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 914,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 2,
            levels: [
              {
                codeNumber: 921,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 922,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 923,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 924,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 3,
            levels: [
              {
                codeNumber: 931,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 932,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 933,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 934,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 4,
            levels: [
              {
                codeNumber: 941,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 942,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 943,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 944,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 5,
            levels: [
              {
                codeNumber: 951,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 952,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 953,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 954,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 6,
            levels: [
              {
                codeNumber: 961,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 962,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 963,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 964,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 7,
            levels: [
              {
                codeNumber: 971,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 972,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 973,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 974,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
          {
            chapter: 8,
            levels: [
              {
                codeNumber: 981,
                level: "levelOne",
                title: "آسان",
                icon:FcLike,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/1.jpg",
                  pdf: "/pdfs/1.pdf",
                },
              },
              {
                codeNumber: 982,
                level: "levelTow",
                title: "متوسط",
                icon:FcReading,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/2.jpg",
                  pdf: "/pdfs/2.pdf",
                },
              },
              {
                codeNumber: 983,
                level: "levelThree",
                title: "سخت",
                icon:FcGraduationCap,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/3.jpg",
                  pdf: "/pdfs/3.pdf",
                },
              },
              {
                codeNumber: 984,
                level: "levelFour",
                title: "تیز هوشان",
                icon:FcFlashOn,
                content: {
                  videos: [
                    {
                      isFree: true,
                      vid: "/videos/vid1.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: true,
                      vid: "/videos/vid2.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid3.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid4.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                    {
                      isFree: false,
                      vid: "/videos/vid5.mp4",
                      subjectVid: "عنوان آزمایشی",
                    },
                  ],
                  img: "/images/worksheet/4.jpg",
                  pdf: "/pdfs/4.pdf",
                },
              },
            ],
          },
        ],
      },
    ],
  },
];

export default course;
