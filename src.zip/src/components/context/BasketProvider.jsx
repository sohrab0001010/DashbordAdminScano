import React, { useState } from 'react'
import BasketContext from "./BasketContext"

const BasketProvider = ({children}) => {

    const [basket,setBasket] = useState([])

    const addToBasket = book => {
        const newBook = {
            id:book.id,
            title:book.title,
            price:book.price,
            image:book.imgBook,
        }

        setBasket(prev => [...prev,newBook])
        
    }

  return (
    <BasketContext.Provider value={{basket,addToBasket}}>
        {children}
    </BasketContext.Provider>
  )
}

export default BasketProvider
