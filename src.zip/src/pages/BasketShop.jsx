import React, { useContext } from 'react'
import BasketContext from '../components/context/BasketContext'

const BasketShop = () => {

  const {basket} = useContext(BasketContext)

  console.log(basket)

  return (
    <div>BasketShop</div>
  )
}

export default BasketShop